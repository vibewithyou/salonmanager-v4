// app/Models/Appointment.php – Inhalt placeholder Schritt 19
