// vite.config.js – Inhalt placeholder Schritt 65
