// app/Http/Controllers/InspirationController.php – Inhalt placeholder Schritt 14
