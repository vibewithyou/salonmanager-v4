// app/Models/Appointment.php – Inhalt placeholder Schritt 16
